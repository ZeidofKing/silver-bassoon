# ExoCord-Discord-Server-Cloner

1. Enter token in .env
2. Run start.bat

const sleep = (t) => new Promise((s) => setTimeout(s, t));

export { sleep };
